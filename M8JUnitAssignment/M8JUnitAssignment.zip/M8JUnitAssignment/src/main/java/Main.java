public class Main {
    public static void main(String[] args) {
    GetDay getDay = new GetDay();
        System.out.println(getDay.getDay(null));

    }

}
